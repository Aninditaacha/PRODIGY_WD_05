# PRODIGY_WD_05
Created a web page that fetches weather data from a weather API based on the user's location or a user-inputted location. It Displays the current weather conditions, temperature, and other relevant information.


https://github.com/Tanmay7586/PRODIGY_WD_05/assets/94454903/3c1ce766-0bfd-4baf-81d9-e92bf60abdf6

